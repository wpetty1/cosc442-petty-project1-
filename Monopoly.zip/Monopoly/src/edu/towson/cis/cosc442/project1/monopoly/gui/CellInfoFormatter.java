package edu.towson.cis.cosc442.project1.monopoly.gui;

import edu.towson.cis.cosc442.project1.monopoly.Cell;

public interface CellInfoFormatter {
    public String format(Cell cell);
}
